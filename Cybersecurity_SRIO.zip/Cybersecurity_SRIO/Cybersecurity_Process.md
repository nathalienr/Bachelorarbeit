# Cybersecurity Process

## GOAL
Threat Analysis and Risk Assessment (TARA) is the core activity to identify and treat cybersecurity threats and risks for the System under Consideration (SUC).

This page describes the procedure and required input information for a product-level TARA of SRIO. The process uses the Microsoft Threat Modeling Tool with an industrial template.

Before modeling starts, the SUC must be clearly defined (boundaries, interfaces, assumptions, and intended operation).

## Setting the System under consideration (SUC)
### Clear identification and description of the system
The SUC definition is the basis for the threat analysis. The following information must be available:
- System description and boundaries.
- Overview architecture.
- Overview of internal and external interfaces and communication protocols.
- Scope of use and target group.
- Intended use and reasonably foreseeable misuse.
- Device type classification.
- Critical resources and assets.
- Data and memory classification.
- Exposure level and environmental assumptions.
- Communication capabilities.
- Protection objectives.
- Relevant attacker profiles and motivations.
- Lifecycle roles and dependencies.
- Explicit out-of-scope elements.
- Trust boundaries.


### Determination of the limits of low-voltage equipment
According to CENELEC Guide 32 (1st edition, 2014-07), section 5, the following assumptions apply:
- The device is intended for operation in an IEC EN 62443-1-1 compliant environment.
- The user/operator must perform a system-level risk assessment for the concrete application.
- Product-level measures alone cannot mitigate all IT-security risks.
- Additional system-side measures and functions are required.
- Physical protection of the device is part of the operator responsibility based on risk analysis.


# Overview Architecture
SRIO is a fieldbus device that:
- Detects binary 24V input signals and transmits them to the higher-level controller via fieldbus.
- Receives output commands from the controller and actuates outputs using binary 24V signals.

Covered functional safety behavior:
- Safe input path: sensor state acquisition and transmission via bus.
- Safe output path: forced switch-off and maintained OFF state in case of dangerous internal failures.

## Blockdiagramm
Functional modules:

| Module | Function |
| ----- | -------- |
| COM   | Ethernetbased communication PROFINET, IoTCore |
| SysCom| SPI based communication between COM / CPU3 and SCPU|
| SCPU | Safe Core containing both SPCUs, rotary switch and Watchdog. Safety functions are implemented in a 1oo2 architecture via SCPU1, SCPU2, the crosscomunication IPC and Watchdog |
| PS    | Power Supply, supplies all system components|
| DI    | Safe Digital Inputs |
| DO    | Safe Digital Outputs |

---
![SystemBlockdiagramm](Pictures/SystemBlockdiagramm.png)
---

## Reduced Blockdiagramm for Security
Diagram reduced to security relevant parts, excludign / reducing the other parts:

---
![SystemBlockdiagramm_Security](Pictures/SystemBlockdiagramm_Security.png)
---

# Overview of interfaces (internal and external) and the available communication protocols

![SRIO Drawing](Pictures/SRIO_Drawing.png)

External interfaces:
- Ethernet / COM module:
	- PROFINET communication to PLC/F-Host.
	- IoTCore communication interface.
- Power supply:
	- Device supply (including daisychaining).
- Rotary switches:
	- Local selection of specific device functions (for example update mode / addressing).
- Safety I/O terminals:
	- 6x F-DI and 2x F-DO signal interfaces.
- LEDs:
	- Local status indication.

Internal interfaces, listed for completeness, physically protected by encapsulated hardware design:
- SysCom: COM <-> SCPU
- IPC: SCPU1 <-> SCPU2
- JTAG interfaces per CPU 

- - - - - - - - - - - - 
Network/protocol context:
- PROFINET over Ethernet (M12 D-coded), bidirectional SRIO <-> PLC/F-Host.
- PROFIsafe as black-channel protocol over PROFINET for safety-relevant communication.
- IoTCore via HTTP/JSON for non-safety service functions (diagnostics, monitoring, error log, firmware update handling).

Field/local interface context:
- Field side: DI/DO plus associated supply paths (US/UA), according to intended port use.
- Local side: rotary switches, LEDs, firmware update mode.


# Classification of the SUC
Name: Safe Remote IO (SRIO)
- eco310 / AL400S / PROFIsafe 6x2 F-DI 2x2 F-DO IP67
- eco310 / AL401S / PROFIsafe 6x2 F-DI 2x2 F-DO IP69K

Safety context:
- IEC 61508 SIL3
- EN ISO 13849-1 PL e Cat.4

Functional role:
- Functionally safe remote I/O module in a PROFINET / PROFIsafe network.
- Safe gateway between safe sensors/actuators and an F-Host (PLC).
- Additional non-safety IoT interface for diagnostics and service functions.


## Determination of the scope of application and the target group
### Scope
This TARA covers the SRIO product behavior and interfaces as described in this document.

Included:
- Product-level cybersecurity analysis for COM, SCPU, IPC, field interfaces and IoTCore interface.
- Typical deployment in industrial machine networks (field level / cell level).

Assumption:
- Primary functional configuration is performed by the controller side (PLC/F-Host).

Excluded from this product TARA:
- Complete plant/network architecture risk treatment at operator level.
- Third-party controller hardening details (handled by controller vendor and operator).

### Target group
Trained personel, e.g. Integrators and operators

## Intended use / reasonably foreseeable misuse
Intended use:
- Safe inputs: acquisition of sensor states, input diagnostics, transfer to F-Host via PROFIsafe.
- Safe outputs: safe actuation of actuators according to PROFIsafe commands.
- Non-safety side functions via IoTCore (HTTP/JSON): diagnostics, monitoring, firmware update workflow, error log and device information.

Reasonably foreseeable misuse:
| Misuse scenario | Comment |
| --- | --- |
| Connection to unsecured networks | For example direct connection to enterprise IT |
| Use of IoT interface from untrusted networks | Increased external reachability |
| Firmware update manipulation | Invalid or manipulated firmware |
| Rotary switch manipulation | F-address / function selection altered |
| Incorrect parameterization | PROFIsafe / iPar misconfiguration |
| Physical device access | Opening, debug/service access |

## Device Type classification
Device Type Classification: Embedded Device with Gateway Characteristics.
Rationale:
- Primary purpose is execution of functional safety functions (safe sensing and safe actuation).
- Communication functions (PROFINET, PROFIsafe transport, IoTCore) support the primary function.
- Due to its position between F-Host and field devices, SRIO also has gateway characteristics.

Implication for later threat modeling:
- Embedded-device threats are prioritized.
- Network/gateway threats are additionally evaluated.

## Overview of critical ressources and "assets"

| Asset | Content | Protection objectives |
| --- | --- | --- |
| A1 Ethernet Profinet/ProfiSafe | F-DI status, F-DO commands, qualifier as part of the PROFIsafe Frame | Integrity, Availability |
| A2 Firmware | COM firmware, SCPU firmware, bootloader | Integrity, Authenticity |
| A3 Safety mechanisms | Watchdog, IPC, cross-communication, safety state machine | Integrity, Availability |
| A4 Credentials and keys | Authentification details, certificate, possible network credentials | Confidentiality, Integrity, Authenticity |
| A5 Diagnostic and service data | Error logs, diagnostic data, device information | Integrity, Confidentiality (medium) |


----

Aus TARA_SRIO_old.xlsx
|Asset Name|	Asset ID|
|---|---|
|LED|	1|
|Ethernet / COM Modul Profinet/ProfiSafe|	2|
|Ethernet / COM Modul IoT Core|	3|
|Power Supply|	4|
|Drehschalter|	5|
|Funktional sichere IOs|	6|
|JTAG-Interfaces pro CPU|	7|
|Device	|8|






## Data classification (optional)
Suggested minimum data classes for TARA:
- Safety-critical control/process data (high integrity and availability requirement).
- Security configuration and identity material (high integrity/authenticity, partly confidentiality).
- Service and diagnostic data (medium confidentiality, high integrity for traceability).

## Memory classification
| Memory | Classification| Usage |
| ---    | ---   | --- |
| EEPROM COM | non volatile | Device Information / Identification parameter; Contains certificate, user is able to save a devicetag / devicename|
| Flash | volatile | used for Update, to save the Update Container |
| shared Update Flash| volatile | used for Update to provide SCPU1 the safe FW-Container|
| EEPROM SPCU1| non volatile | Device Informations / Adress for Safe communication (future usescase)|
| EEPROM SCPU2| non volatile | Device Informations / Adress for Safe communication (future usescase)|


## other non specific properties
n/a

## Exposure Level
Typical deployment exposure:
- Zone Level 1 (fieldbus level).
- Zone Level 2 (machine network / cell level).

Direct internet exposure is not intended.

## Definition of communication capabilities
- Cyclic and acyclic PROFINET communication with PLC/F-Host.
- PROFIsafe communication via black channel over PROFINET.
- IoTCore HTTP/JSON communication for service functions.
    -> Component can be accessed directly from the operator network or from another zone with different security requirements
- Local configuration capability via rotary switches.

## Definition of protection objectives
Primary protection objectives for SRIO:
- Integrity: prevent unauthorized modification of safety-relevant data, firmware and control paths.
- Availability: maintain safe operation and deterministic fail-safe behavior under fault/attack conditions.
- Authenticity: ensure trusted communication peers and trusted software/update origin.
- Confidentiality: protect sensitive credentials and security-relevant service data.

## Definition of Attackers and their motivation
Relevant attacker classes for SRIO context:

High relevance:
- Low-budget cybercriminal / opportunistic attacker (network exploitation, ransomware-driven disruption).
- Casual attacker with access to local network segment.

Lower relevance in the assumed deployment model:
- Script kiddies without access path to the protected industrial network.

Typical motivations:
- Service disruption.
- Manipulation of behavior or process values.
- Unauthorized firmware/configuration change.
- Information gathering via diagnostics.

## Determination of lifecycle and the related users and other dependencies, based on customer journey

!ToDo!


## Determination of what is not part of the system
Out of scope for the SRIO product TARA:
- Full plant-wide security architecture and SOC operations.
- Security implementation details of third-party PLCs, switches and upper-level IT systems.
- Customer-specific remote access infrastructure.
- Physical perimeter protection of the installation site.

These points must be treated in the operator/system-level risk assessment.

## Setting the Trust Boundaries of the SUC
![SRIO Drawing](Pictures\SystemBlockdiagramm_Security.png)

- TB1: F-Host / PROFINET <-> SRIO (external network trust boundary).
- TB2: SRIO <-> IoT Client (service interface trust boundary).
- TB3: COM <-> SCPU (internal boundary between communication stack and safety control logic).
- TB4: SCPU1 <-> SCPU2 (IPC boundary inside safety architecture): **Excluded since behind TB3**
- TB5: SRIO <-> Sensors (field input boundary): **Excluded since binary interface**
- TB6: SRIO <-> Actuators (field output boundary): **Exclude since binary interface**

- TB7: Firmware update source <-> SRIO (software supply/update trust boundary).


# Documentation
Required documentation outputs of this TARA:
- SUC definition with assumptions and boundaries. 
- Threat model artifacts (data flows, boundaries, threats, mitigations).
- Asset and protection-objective mapping.
- Risk evaluation and treatment decisions.
- Residual risks and explicit external dependencies.
- Requirements for verification/validation and customer documentation handover.

# Identify Cybersecurity requirements for environment
TARA results can include requirements that are outside product responsibility and must be fulfilled by integrator/operator environment.

Typical external dependencies to document in system specification and customer documentation:
- Time synchronization (for example NTP, if required by security functions or logging consistency).
- Backup and restore concept for configuration/log data.
- Network segmentation, firewall rules and access control.
- Physical protection and tamper-response operational procedures.
- Secure remote access concept.

All such external requirements must be explicitly marked as environment responsibilities.



# Maschinenverordnung 2023/1230

1.1.9 Schutz gegen Korrumpierung

Die Maschine bzw. das dazugehörige Produkt muss so konstruiert und gebaut sein, dass der Anschluss von einer anderen Einrichtung an die Maschine oder das dazugehörige Produkt durch jede Funktion der angeschlossenen Einrichtung selbst oder über eine mit der Maschine bzw. dem dazugehörigen Produkt kommunizierende entfernte Fernzugriffseinrichtung nicht zu einer gefährlichen Situation führt.

**Keine Gefährdung darf von unserem Produkt ausgehen; **

Durch Risikobeurteilung nach MRL und Funktionale Sicherheit = garantierte Funktion gegeben?
Ein Hardware-Bauteil, das Signale oder Daten überträgt, die für den Anschluss oder den Zugriff auf die Software relevant sind, die für die Übereinstimmung einer Maschine oder eines dazugehörigen Produkts mit den einschlägigen Sicherheits- und Gesundheitsschutzanforderungen von entscheidender Bedeutung ist, muss so konstruiert sein, dass es angemessen gegen unbeabsichtigte oder vorsätzliche Korrumpierung geschützt ist. 
**Passt, weil umspritzt**
Maschinen bzw. dazugehörige Produkte müssen Beweise für ein rechtmäßiges oder unrechtmäßiges Eingreifen in das genannte Hardware-Bauteil sammeln, soweit es für den Anschluss oder den Zugriff auf die Software relevant ist, die für die Konformität der Maschinen bzw. dazugehörigen Produkte von entscheidender Bedeutung ist.

**Bei uns nicht gegeben, nur durch optische Kontrolle möglich?**

Software und Daten, die für die Übereinstimmung der Maschine oder des dazugehörigen Produkts mit den einschlägigen Sicherheits- und Gesundheitsschutzanforderungen von entscheidender Bedeutung sind, sind als solche zu benennen und angemessen gegen unbeabsichtigte oder vorsätzliche Korrumpierung zu schützen. Die Maschine bzw. das dazugehörige Produkt muss die installierte Software, die für den sicheren Betrieb erforderlich ist, kenntlich machen und diese Informationen jederzeit in leicht zugänglicher Form bereitstellen können. Maschinen bzw. dazugehörige Produkte müssen Nachweise für ein rechtmäßiges oder unrechtmäßiges Eingreifen in die Software oder eine Veränderung der in Maschinen bzw. dazugehörigen Produkte installierten Software oder ihrer Konfiguration sammeln

**??**

1.2.1. Sicherheit und Zuverlässigkeit von Steuerungen
Steuerungen sind so zu konzipieren und zu bauen, dass es nicht zu Gefährdungssituationen kommt. Steuerungen müssen so ausgelegt und beschaffen sein, dass 

a) sie, wenn den Umständen und Risiken angemessen, den zu erwartenden Betriebsbeanspruchungen sowie beabsichtigten und unbeabsichtigten Fremdeinflüssen, einschließlich vernünftigerweise vorhersehbare böswillige Versuche Dritter, die zu einer Gefährdungssituation führen, standhalten können; 

[….]

f) das Rückverfolgungsprotokoll der Daten, das im Zusammenhang mit einem Eingreifen generiert wurden, und der Versionen der Sicherheitssoftware, die nach dem Inverkehrbringen oder der Inbetriebnahme der Maschine oder des dazugehörigen Produkts hochgeladen wurden, bis zu fünf Jahre nach dem Hochladen ausschließlich für den Nachweis der Konformität der Maschine oder des dazugehörigen Produkts mit diesem Anhang auf begründete Anforderung einer zuständigen nationalen Behörde zugänglich ist. 

